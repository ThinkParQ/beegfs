#ifndef MCTP3_THREADP_H
#define MCTP3_THREADP_H

#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifndef WIN32
typedef unsigned long mctpCycles;
#else
typedef __int64 mctpCycles;
#endif

#define MCTP3_MAJOR_VERSION (0)
#define MCTP3_MINOR_VERSION (9)
#define MCTP3_REVISION (7)

//  fast thread local variables
#ifdef linux
extern __thread int __mctp_thread_tid;
extern __thread int __mctp_thread_tnc;
#else
extern __declspec(thread) int __mctp_thread_tid;
extern __declspec(thread) int __mctp_thread_tnc;
#endif


//  # available cpu cores
int mctpGetNumberOfCores();
//  returns activated cores (all available cores)
int mctpInit();
//  returns activated cores (specified by caller)
int mctpInitUser(const unsigned int use_nr_of_threads);
int mctpGetNumberOfActivatedCores();
//  finalize everything
void mctpCleanup();
//  current version
float mctpGetVersion();
//  threads ctrl0
int mctpRun(void* (*function)(void*),void *arg);
//  sync all activated threads
void mctpSync();
void mctpSyncPassive();
//  simple affinity mapping
int mctpThread2CoreAffinity(unsigned int core);
//  maps calling thread onto socket
int mctpThread2SocketAffinity(unsigned int socket);
//  prints out current affinity mask
int mctpPrintAffinityMask();
//  64byte aligned malloc
void *mallocCA(size_t size);
void freeCA(void *ptr);
int  mctpGetMallocCASize();
//  measured cpu freq
float mctpCpuFreq();
mctpCycles mctpGetCycles();
float mctpCycles2Secs (const mctpCycles c);
float mctpCycles2MSecs(const mctpCycles c);
//  msec sleep
void mctpSleep(const int msec);

#ifdef __cplusplus
}
#endif

#endif
