#include <stdlib.h>

/* Simple test with failure exit to test gaspi_run */
int main(int argc, char *argv[])
{

  exit(EXIT_FAILURE);
}
