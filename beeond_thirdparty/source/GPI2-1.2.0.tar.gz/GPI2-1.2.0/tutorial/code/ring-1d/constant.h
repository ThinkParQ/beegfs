#ifndef CONSTANT_H
#define CONSTANT_H

static const int VLEN = 16;
static const int NITER = 8192;

#endif
