#ifndef TESTSOME_H
#define TESTSOME_H

#include <GASPI.h>

int test_or_die ( gaspi_segment_id_t
                , gaspi_notification_id_t
                , gaspi_notification_t expected
                );

#endif
