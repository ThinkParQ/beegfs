#ifndef NOW_H
#define NOW_H

double now();

#endif
