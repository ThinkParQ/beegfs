#define _LARGEFILE64_SOURCE
#define MAX_THREADS (256)
#define STACKSIZE (16*1024*1024)
#define MAX_LEN (1024)

#define PCP_MAJOR_VERSION (0)
#define PCP_MINOR_VERSION (9)
#define PCP_REVISION (4)


#include <GASPI.h>
#include <mctp3.h>

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <memory.h>
#include <sys/timeb.h>
#include <stdint.h>
#include <unistd.h>
#include <pthread.h>
#include <getopt.h>
#include <errno.h>
#include <limits.h>
#include <vector>
#include <string>
#include <sys/resource.h>
#include <dirent.h>
#include <stdarg.h>

using namespace std;

//globals
gaspi_rank_t rank,tnc,atc;
int maxThreads=0,tcount=1;
ulong psize=16;//mb
ulong csize=16;//mb
ulong psizeBytes=psize*1024*1024;
ulong csizeBytes=csize*1024*1024;
vector<string> cpArgs;
char *opBuf[MAX_THREADS];
char *curDir[MAX_THREADS];
ulong fcnt[MAX_THREADS];
char outDir[PATH_MAX];
uint recThres=1000;//low value to avoid stack overrun
uint modCI,glbTID;
ulong opBytes[MAX_THREADS];
ulong opFiles[MAX_THREADS];
bool showStats=false;

static pthread_mutex_t ioLock = PTHREAD_MUTEX_INITIALIZER;

void error_printf(const char *fmt, ...){
char buf[1024];

  memset(buf,0,1024);

  va_list ap;
  //try to print into the allocated space
  va_start(ap,fmt);
  vsnprintf(buf,1024,fmt,ap);
  va_end(ap);

  fprintf(stderr,"%s",buf);
}

#define printf  error_printf

void printError(){
pthread_mutex_lock(&ioLock);
  printf("errno:%d error: %s\n",errno,strerror(errno));
pthread_mutex_unlock(&ioLock);
exit(-1);
}

void setStackSize(const int size){
const rlim_t ssize = size;
struct rlimit rl;

  if(getrlimit(RLIMIT_STACK,&rl)==0){
    if(rl.rlim_cur < ssize){
      rl.rlim_cur = ssize;
      if(setrlimit(RLIMIT_STACK,&rl)!=0){printf("set stacksize failed !\n");}
      else{ recThres = (ssize-ssize/10)/1024;}
    }
  }
}

void cpPartFile(const char *fn,const struct stat &sbuf){
char tmpBuf[MAX_LEN];

const ulong cpInst = rank*atc+__mctp_thread_tid;
const ulong value  = sbuf.st_size/modCI;
const ulong start  = cpInst*value;
ulong len = value;
const ulong last = modCI-1;
if(cpInst==last) len = sbuf.st_size - last*value;

  opFiles[__mctp_thread_tid]++;
  opBytes[__mctp_thread_tid]+=len;

  const char *name = rindex(fn,'/');
  if(name==NULL){printf("filename is null !\n");exit(-1);}

  snprintf(tmpBuf,MAX_LEN,"%s%s",curDir[__mctp_thread_tid],name);

  //divide into chunck sizes
  const ulong full = len/csizeBytes;
  const ulong rest = len-(full*csizeBytes);

  char *ptr = opBuf[__mctp_thread_tid];

  int fd = open(fn,O_RDONLY); 
  if(fd<0){printf("open failed ! -> %s\n",fn);printError();}

  int fd2 = open(tmpBuf,O_WRONLY|O_CREAT,sbuf.st_mode);
  if(fd2<0){printf("open failed ! -> %s\n",tmpBuf);printError();}

  ulong sum=0;
  ulong size=csizeBytes;
  ulong start2=start;

  for(int f=0;f<full;f++){
    sum=0;

    while(sum<size){
      const int lret = pread(fd,ptr+sum,size-sum,start2+sum);
      if(lret!=-1) sum+=lret;
      else{printf("reading data failed !\n");printError();}
    }
  
    sum=0;

    while(sum<size){
      const int lret = pwrite(fd2,ptr+sum,size-sum,start2+sum);
      if(lret!=-1) sum+=lret;
      else{printf("writing data failed ! -> %s\n",tmpBuf);printError();}
    }

    start2+=size;
  }//full

  sum=0;
  size=rest;

  while(sum<size){
    const int lret = pread(fd,ptr+sum,size-sum,start2+sum);
    if(lret!=-1) sum+=lret;
    else{printf("reading data failed !\n");printError();}
  }

  sum=0;

  while(sum<size){
    const int lret = pwrite(fd2,ptr+sum,size-sum,start2+sum);
    if(lret!=-1) sum+=lret;
    else{printf("writing data failed ! -> \n",tmpBuf);printError();}
  }

  if(cpInst==last){
    struct stat sbuf2;
    if(lstat(tmpBuf,&sbuf2) < 0){printf("fstat failed\n");printError();}

    if(sbuf2.st_size != sbuf.st_size){
      //truncate
      if(ftruncate(fd2,sbuf.st_size)!=0){printf("ftruncate failed !\n");printError();}
    }

  }

  if(fchmod(fd2,sbuf.st_mode)!=0){printf("chmod failed ! -> %s\n",tmpBuf);printError();}

  close(fd);
  close(fd2);

}


void cpRegFile(const char *fn){
char tmpBuf[MAX_LEN];
struct stat sbuf;


  if(lstat(fn,&sbuf) < 0){printf("fstat failed\n");printError();}

  //check filesize -> partCopy for all (maybe truncate)
  if(sbuf.st_size > psizeBytes) return cpPartFile(fn,sbuf);

  //work for us ? count regFiles mod copy-instances != tid -> return
  if( !((fcnt[__mctp_thread_tid]++ % modCI)==(rank*atc+__mctp_thread_tid) )) return;

  const char *name = rindex(fn,'/');
  if(name==NULL){printf("filename is null !\n");exit(-1);}

  snprintf(tmpBuf,MAX_LEN,"%s%s",curDir[__mctp_thread_tid],name);

  opFiles[__mctp_thread_tid]++;
  opBytes[__mctp_thread_tid]+=sbuf.st_size;

  //divide into chunck sizes
  const ulong full = sbuf.st_size/csizeBytes;
  const ulong rest = sbuf.st_size-(full*csizeBytes);

  char *ptr = opBuf[__mctp_thread_tid];

  int fd = open(fn,O_RDONLY); 
  if(fd<0){printf("open failed ! -> %s\n",fn);printError();}

  int fd2 = open(tmpBuf,O_WRONLY|O_CREAT|O_TRUNC,sbuf.st_mode);
  if(fd2<0){printf("open failed ! -> %s\n",tmpBuf);printError();}


  ulong sum=0;
  ulong size=csizeBytes;

  for(int f=0;f<full;f++){
    sum=0;

    while(sum<size){
      const int lret = read(fd,ptr+sum,size-sum);
      if(lret!=-1) sum+=lret;
      else{printf("reading data failed !\n");printError();}
    }
  
    sum=0;

    while(sum<size){
      const int lret = write(fd2,ptr+sum,size-sum);
      if(lret!=-1) sum+=lret;
      else{printf("writing data failed ! -> %s\n",tmpBuf);printError();}
    }

  }//full

  sum=0;
  size=rest;

  while(sum<size){
    const int lret = read(fd,ptr+sum,size-sum);
    if(lret!=-1) sum+=lret;
    else{printf("reading data failed !\n");printError();}
  }

  sum=0;

  while(sum<size){
    const int lret = write(fd2,ptr+sum,size-sum);
    if(lret!=-1) sum+=lret;
    else{printf("writing data failed ! -> \n",tmpBuf);printError();}
  }


  if(fchmod(fd2,sbuf.st_mode)!=0){printf("chmod failed ! -> %s\n",tmpBuf);printError();}

  close(fd);
  close(fd2);

}


void cpLnk(const char *path){
char buf[MAX_LEN];

  printf("%d soft link detected !\n",__mctp_thread_tid);
  memset(buf,0,MAX_LEN); 
  readlink(path,buf,MAX_LEN);
  symlink(buf,"/tmp/odir");
}

void setOPath(const char *path,const int pos){
int idx;
char tmpBuf[MAX_LEN];
  
  strcpy(tmpBuf,path);

  for(int i=0;i<pos;i++){
    char *name = rindex(tmpBuf,'/');
    idx = name-tmpBuf;
    tmpBuf[idx]='\0';
  }

  snprintf(curDir[__mctp_thread_tid],MAX_LEN,"%s%s",outDir,path+idx);

}

void cpDir(const char *path,const int pos){
DIR *dir;
int gen=pos;
struct stat sbuf;

  if(lstat(path,&sbuf) < 0){printf("fstat failed\n");exit(-1);}

  //mutex ???
  setOPath(path,pos+1);

  if(mkdir(curDir[__mctp_thread_tid],sbuf.st_mode)!=0){
    if(errno!=EEXIST){printf("%d:%d mkdir failed ! -> %s\n",rank,__mctp_thread_tid,curDir[__mctp_thread_tid]);printError();}
  }

  dir = opendir(path);
  if(!dir){printf("opendir failed ! -> %s\n",path);exit(-1);}
       
  while(1){

    struct dirent entry;
    struct dirent *result;
    char sub_path[MAX_LEN];
 
    if(readdir_r(dir,&entry,&result)!=0){printf("readdir failed !\n");exit(-1);}
       
    if(result==NULL) break;//end of tree
 
    char *name = result->d_name;
    if((strcmp(name,".") == 0) || (strcmp(name,"..") == 0)) continue;
 
    if(result->d_type == DT_DIR){
      sprintf(sub_path,"%s/%s",path,name);
      if(pos<recThres) cpDir(sub_path,pos+1);
      else{printf("recursion limit exceeded !\n");exit(-1);}
    }
    else if(result->d_type == DT_REG){
      //printf("gen dest path from:%s pos:%d gen:%d\n",path,pos,gen);
      if(gen!=-1) setOPath(path,pos+1);
      snprintf(sub_path,MAX_LEN,"%s/%s",path,name);
      //printf("file: %s pos:%d\n",sub_path,pos);
      cpRegFile(sub_path);
      gen=-1;
    }/*
    else if(result->d_type == DT_LNK){//has to be discussed how to handle soft links
      if(gen!=-1) setOPath(path,pos+1);
      snprintf(sub_path,MAX_LEN,"%s/%s",path,name);
      cpLnk(sub_path);
      gen=-1;
    }*/    
  
  }//while(1)
    
  if(closedir(dir)!=0){printf("closedir failed !\n");exit(-1);}

}



void pcp(){
struct stat sbuf;

  //alloc io-buffers per thread
  opBuf[__mctp_thread_tid] = (char*)mallocCA(csizeBytes);
  if(opBuf[__mctp_thread_tid]==NULL){printf("malloc failed !\n");exit(-1);}

  curDir[__mctp_thread_tid] = (char*)mallocCA(MAX_LEN);
  if(curDir[__mctp_thread_tid]==NULL){printf("malloc failed !\n");exit(-1);}

  for(int i=0;i<cpArgs.size()-1;i++){
  
    const char *fn = cpArgs[i].c_str();
    if(lstat(fn,&sbuf) < 0){printf("fstat failed\n");exit(-1);}

    if(S_ISREG(sbuf.st_mode)){ 
      snprintf(curDir[__mctp_thread_tid],MAX_LEN,"%s",outDir);
      cpRegFile(fn);
    }
    else if(S_ISDIR(sbuf.st_mode)){ 
      snprintf(curDir[__mctp_thread_tid],MAX_LEN,"%s",outDir);
      cpDir(fn,0);
    }
    
  }//for

  freeCA(opBuf[__mctp_thread_tid]);
  freeCA(curDir[__mctp_thread_tid]);
}

void *threadfkt(void *arg){
timeb startT,endT;

  setStackSize(STACKSIZE);

  mctpSyncPassive();
ftime(&startT);
  pcp();
ftime(&endT);

if(showStats){

const float total=(endT.time-startT.time)+(endT.millitm-startT.millitm)/1.e3;
const float mb  = (float)opBytes[__mctp_thread_tid]/(1024.0f*1024.0f);
const float mbs = mb/total;

  printf("%d:%d pcp time(s): %.2f (#Files:%lu, %.1f mb, %.1f mb/s)\n",rank,__mctp_thread_tid,total,opFiles[__mctp_thread_tid],mb,mbs);
}

  mctpSyncPassive();

}

void options(int argc,char *argv[]){

static struct option long_options[] = {{"debug",0,0,'d'},{"threads",1,0,'t'},{"psize",1,0,'s'},{"csize",1,0,'c'},{0,0,0,0}};

while(1){
  int c = getopt_long(argc,argv,"l;t:s:c:",long_options,NULL);
  if(c==-1) break;

  switch(c){
  case 'l':
    showStats=true;
    break;

  case 't':
    if(sscanf(optarg,"%d",&tcount)!=1){printf("invalid option parameter !\n");exit(-1);}

    if(tcount<=0 || tcount >maxThreads){printf("option parameter out of range !\n");exit(-1);}
    break;

  case 's':
    if(sscanf(optarg,"%lu",&psize)!=1){printf("invalid option parameter !\n");exit(-1);}

    if(psize<=0){printf("option parameter out of range !\n");exit(-1);}
    psizeBytes=psize*1024*1024;
    break;

  case 'c':
    if(sscanf(optarg,"%lu",&csize)!=1){printf("invalid option parameter !\n");exit(-1);}

    if(csize<=0 || csize>1024){printf("option parameter out of range !\n");exit(-1);}
    csizeBytes=csize*1024*1024;
    break;

  case '?':
    printf("invalid option parameter !\n");
    exit(-1);
    break;

  };//switch

}//while(1)

}


int main(int argc,char *argv[]){
char tmpBuf[PATH_MAX];
struct stat sbuf;
timeb startT,endT,startG,endG;

  memset(opBytes,0,MAX_THREADS*sizeof(ulong));
  memset(opFiles,0,MAX_THREADS*sizeof(ulong));

  if(argc<2){printf("missing arguments !\n");exit(-1);}

  setStackSize(STACKSIZE);
  cpArgs.clear();

  maxThreads = mctpGetNumberOfCores();
  if(maxThreads > MAX_THREADS){printf("too many threads !\n");exit(-1);}

  options(argc,argv);
  if(optind>(argc-2)){printf("missing arguments !\n");exit(-1);}

  if(realpath(argv[argc-1],tmpBuf)==NULL){printf("invalid path !\n");exit(-1);}
  snprintf(outDir,MAX_LEN,"%s",tmpBuf);

  //source(s) and dest folder
  for(int i=optind;i<argc;i++){

    if(realpath(argv[i],tmpBuf)==NULL){printf("invalid path !\n");exit(-1);}
    if((i<argc-1) && strcmp(tmpBuf,outDir)==0){printf("path duplication detected !\n");exit(-1);}

    cpArgs.push_back(tmpBuf);

    if(i==(argc-1)){
      //check dest dir
      if(lstat(argv[i],&sbuf) < 0){printf("fstat failed !\n");exit(-1);}
      if(!S_ISDIR(sbuf.st_mode)){printf("no dest. directory !\n");exit(-1);}
    }
  }

  gaspi_config_t default_conf;
  gaspi_config_get(&default_conf);
  default_conf.queue_num = 0;
  gaspi_config_set(default_conf);

ftime(&startT);
  if(gaspi_proc_init(GASPI_BLOCK)!=GASPI_SUCCESS){printf("gpi2 startup failed !\n");exit(-1);}
  gaspi_barrier(GASPI_GROUP_ALL,GASPI_BLOCK);
ftime(&endT);

  gaspi_proc_rank(&rank);
  gaspi_proc_num(&tnc);

const float totalS=(endT.time-startT.time)+(endT.millitm-startT.millitm)/1.e3;
if(rank==0) printf("pcp startup time(s): %.2f\n",totalS);

  //threads
  mctpInitUser(tcount);
  atc = mctpGetNumberOfActivatedCores();

  memset(fcnt,0,MAX_THREADS*sizeof(ulong));
  modCI=tnc*atc;

  for(int t=0;t<atc-1;t++)mctpRun(threadfkt,NULL);

  mctpSyncPassive();
ftime(&startT);
ftime(&startG);
  pcp();
ftime(&endT);
  mctpSyncPassive();

  //gaspi_barrier(GASPI_GROUP_ALL,GASPI_BLOCK);
  ulong localV=0,allV=0;
  for(int i=0;i<atc;i++) localV+= opBytes[i];
 
  gaspi_allreduce(&localV,&allV,1,GASPI_OP_SUM,GASPI_TYPE_ULONG,GASPI_GROUP_ALL,GASPI_BLOCK);
ftime(&endG);

  gaspi_proc_term(GASPI_BLOCK);

if(showStats){
const float total=(endT.time-startT.time)+(endT.millitm-startT.millitm)/1.e3;
const float mb  = (float)opBytes[__mctp_thread_tid]/(1024.0f*1024.0f);
const float mbs = mb/total;

  printf("%d:%d pcp time(s): %.2f (#Files:%lu, %.1f mb, %.1f mb/s)\n",rank,__mctp_thread_tid,total,opFiles[__mctp_thread_tid],mb,mbs);
  fflush(stdout);
}

if(rank==0){
const float totalG=(endG.time-startG.time)+(endG.millitm-startG.millitm)/1.e3;
const float mb  = (float)allV/(1024.0f*1024.0f);
const float mbs = mb/totalG;

  printf("<<< aggr. time(s): %.2f (%.1fmb, %.1f mb/s)>>>\n",totalG,mb,mbs);
}
  

   
return 0;
}
